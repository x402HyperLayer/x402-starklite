import { describe, it, expect } from 'vitest';
import { verifySignature } from '../src/proof/signer.js';
import nacl from 'tweetnacl';

describe('Signature Verification', () => {
  it('should verify a valid signature', () => {
    const keyPair = nacl.sign.keyPair();
    const message = JSON.stringify({ test: 'data' });
    const messageBytes = new TextEncoder().encode(message);
    const signature = nacl.sign.detached(messageBytes, keyPair.secretKey);
    
    const result = verifySignature(
      message,
      Buffer.from(signature).toString('base64'),
      Buffer.from(keyPair.publicKey).toString('base64')
    );
    
    expect(result.verified).toBe(true);
  });
  
  it('should reject an invalid signature', () => {
    const keyPair = nacl.sign.keyPair();
    const message = JSON.stringify({ test: 'data' });
    const fakeSignature = Buffer.from(new Uint8Array(64)).toString('base64');
    
    const result = verifySignature(
      message,
      fakeSignature,
      Buffer.from(keyPair.publicKey).toString('base64')
    );
    
    expect(result.verified).toBe(false);
  });
  
  it('should handle unconfigured public key', () => {
    const message = JSON.stringify({ test: 'data' });
    const signature = Buffer.from(new Uint8Array(64)).toString('base64');
    
    const result = verifySignature(message, signature, 'base64_pubkey_here');
    
    expect(result.verified).toBe(false);
    expect(result.error).toBe('Public key not configured');
  });
  
  it('should reject invalid key length', () => {
    const message = JSON.stringify({ test: 'data' });
    const signature = Buffer.from(new Uint8Array(64)).toString('base64');
    const invalidKey = Buffer.from(new Uint8Array(10)).toString('base64');
    
    const result = verifySignature(message, signature, invalidKey);
    
    expect(result.verified).toBe(false);
    expect(result.error).toContain('Invalid public key length');
  });
});
