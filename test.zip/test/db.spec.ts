import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { ProofStore } from '../src/db/store.js';
import { ProofRecord } from '../src/proof/types.js';
import fs from 'fs';

const TEST_DB = './test.db';

describe('ProofStore', () => {
  let store: ProofStore;
  
  beforeEach(() => {
    if (fs.existsSync(TEST_DB)) {
      fs.unlinkSync(TEST_DB);
    }
    store = new ProofStore(TEST_DB);
  });
  
  afterEach(() => {
    store.close();
    if (fs.existsSync(TEST_DB)) {
      fs.unlinkSync(TEST_DB);
    }
  });
  
  it('should save and retrieve a proof', () => {
    const proof: ProofRecord = {
      id: 'proof_123',
      chain: 'starknet',
      timestamp: '2025-11-19T10:00:00Z',
      payload: { data: 'test' },
      signature: 'sig123',
      receivedAt: new Date().toISOString(),
      sizeRaw: 100,
      sizeGzip: 50,
      verifierStatus: 'pending'
    };
    
    store.saveProof(proof);
    const retrieved = store.getProof('proof_123');
    
    expect(retrieved).toBeDefined();
    expect(retrieved?.id).toBe('proof_123');
    expect(retrieved?.chain).toBe('starknet');
  });
  
  it('should return null for non-existent proof', () => {
    const proof = store.getProof('nonexistent');
    expect(proof).toBeNull();
  });
  
  it('should update verifier status', () => {
    const proof: ProofRecord = {
      id: 'proof_123',
      chain: 'starknet',
      timestamp: '2025-11-19T10:00:00Z',
      payload: { data: 'test' },
      signature: 'sig123',
      receivedAt: new Date().toISOString(),
      sizeRaw: 100,
      sizeGzip: 50,
      verifierStatus: 'pending'
    };
    
    store.saveProof(proof);
    store.updateVerifierStatus('proof_123', 'verified', 'All good');
    
    const updated = store.getProof('proof_123');
    expect(updated?.verifierStatus).toBe('verified');
    expect(updated?.verifierMessage).toBe('All good');
    expect(updated?.verifiedAt).toBeDefined();
  });
  
  it('should calculate metrics correctly', () => {
    const proof1: ProofRecord = {
      id: 'proof_1',
      chain: 'starknet',
      timestamp: '2025-11-19T10:00:00Z',
      payload: { data: 'test' },
      signature: 'sig1',
      receivedAt: new Date().toISOString(),
      sizeRaw: 100,
      sizeGzip: 50,
      verifierStatus: 'pending'
    };
    
    const proof2: ProofRecord = {
      id: 'proof_2',
      chain: 'ethereum',
      timestamp: '2025-11-19T11:00:00Z',
      payload: { data: 'test2' },
      signature: 'sig2',
      receivedAt: new Date().toISOString(),
      sizeRaw: 200,
      sizeGzip: 100,
      verifierStatus: 'verified'
    };
    
    store.saveProof(proof1);
    store.saveProof(proof2);
    
    const metrics = store.getMetrics();
    
    expect(metrics.totalProofs).toBe(2);
    expect(metrics.byStatus.pending).toBe(1);
    expect(metrics.byStatus.verified).toBe(1);
    expect(metrics.byChain.starknet).toBe(1);
    expect(metrics.byChain.ethereum).toBe(1);
    expect(metrics.totalSizeRaw).toBe(300);
    expect(metrics.totalSizeGzip).toBe(150);
  });
});
