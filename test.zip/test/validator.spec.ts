import { describe, it, expect } from 'vitest';
import { validateStarkProof } from '../src/proof/validator.js';

describe('StarkProof Validator', () => {
  it('should validate a correct proof', () => {
    const validProof = {
      id: 'proof_123',
      chain: 'starknet',
      timestamp: '2025-11-19T10:00:00Z',
      payload: { data: 'test' },
      signature: 'base64signature'
    };
    
    const result = validateStarkProof(validProof);
    expect(result.valid).toBe(true);
  });
  
  it('should reject proof without required id field', () => {
    const invalidProof = {
      chain: 'starknet',
      timestamp: '2025-11-19T10:00:00Z',
      payload: { data: 'test' },
      signature: 'base64signature'
    };
    
    const result = validateStarkProof(invalidProof);
    expect(result.valid).toBe(false);
    expect(result.errors).toBeDefined();
  });
  
  it('should reject proof with invalid timestamp format', () => {
    const invalidProof = {
      id: 'proof_123',
      chain: 'starknet',
      timestamp: 'invalid-date',
      payload: { data: 'test' },
      signature: 'base64signature'
    };
    
    const result = validateStarkProof(invalidProof);
    expect(result.valid).toBe(false);
  });
  
  it('should reject proof with additional properties', () => {
    const invalidProof = {
      id: 'proof_123',
      chain: 'starknet',
      timestamp: '2025-11-19T10:00:00Z',
      payload: { data: 'test' },
      signature: 'base64signature',
      extraField: 'not allowed'
    };
    
    const result = validateStarkProof(invalidProof);
    expect(result.valid).toBe(false);
  });
  
  it('should reject proof without signature', () => {
    const invalidProof = {
      id: 'proof_123',
      chain: 'starknet',
      timestamp: '2025-11-19T10:00:00Z',
      payload: { data: 'test' }
    };
    
    const result = validateStarkProof(invalidProof);
    expect(result.valid).toBe(false);
  });
});
