import Ajv from 'ajv';
import addFormats from 'ajv-formats';
import schema from './schema.json' with { type: 'json' };
import { ValidationResult, StarkProof } from './types.js';

const ajv = new Ajv({ allErrors: true });
addFormats(ajv);

const validateProof = ajv.compile(schema);

export function validateStarkProof(data: unknown): ValidationResult {
  const valid = validateProof(data);
  
  if (!valid && validateProof.errors) {
    return {
      valid: false,
      errors: validateProof.errors.map(err => 
        `${err.instancePath} ${err.message}`
      )
    };
  }
  
  return { valid: true };
}

export function isStarkProof(data: unknown): data is StarkProof {
  return validateStarkProof(data).valid;
}
