import { ProofStore } from '../db/store.js';
import { StarkProof, ProofRecord } from './types.js';
import { calculateSize } from '../utils/size.js';
import { logger } from '../utils/logger.js';

export class ProofStorage {
  constructor(private store: ProofStore) {}
  
  async saveProof(proof: StarkProof): Promise<ProofRecord> {
    const sizeMetrics = calculateSize(proof);
    
    const record: ProofRecord = {
      ...proof,
      receivedAt: new Date().toISOString(),
      sizeRaw: sizeMetrics.rawBytes,
      sizeGzip: sizeMetrics.gzipBytes,
      verifierStatus: 'pending'
    };
    
    this.store.saveProof(record);
    logger.info(`Proof stored: ${proof.id}, raw: ${sizeMetrics.rawBytes}B, gzip: ${sizeMetrics.gzipBytes}B`);
    
    return record;
  }
  
  async getProof(id: string): Promise<ProofRecord | null> {
    return this.store.getProof(id);
  }
  
  async updateVerifierStatus(
    id: string,
    status: 'pending' | 'submitted' | 'verified' | 'failed',
    message?: string
  ): Promise<void> {
    this.store.updateVerifierStatus(id, status, message);
  }
}
