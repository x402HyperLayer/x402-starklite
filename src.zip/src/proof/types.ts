export interface StarkProof {
  id: string;
  chain: string;
  timestamp: string;
  payload: Record<string, any>;
  signature: string;
}

export interface ProofRecord extends StarkProof {
  receivedAt: string;
  sizeRaw: number;
  sizeGzip: number;
  verifierStatus: 'pending' | 'submitted' | 'verified' | 'failed';
  verifierMessage?: string;
  verifiedAt?: string;
}

export interface ValidationResult {
  valid: boolean;
  errors?: string[];
}

export interface SignatureVerification {
  verified: boolean;
  error?: string;
}
