import nacl from 'tweetnacl';
import { SignatureVerification } from './types.js';
import { logger } from '../utils/logger.js';

export function verifySignature(
  jsonString: string,
  signatureBase64: string,
  publicKeyBase64: string
): SignatureVerification {
  try {
    if (!publicKeyBase64 || publicKeyBase64 === 'base64_pubkey_here') {
      logger.warn('No valid public key configured, skipping signature verification');
      return {
        verified: false,
        error: 'Public key not configured'
      };
    }

    const message = new TextEncoder().encode(jsonString);
    const signature = Buffer.from(signatureBase64, 'base64');
    const publicKey = Buffer.from(publicKeyBase64, 'base64');
    
    if (publicKey.length !== nacl.sign.publicKeyLength) {
      return {
        verified: false,
        error: `Invalid public key length: expected ${nacl.sign.publicKeyLength}, got ${publicKey.length}`
      };
    }
    
    if (signature.length !== nacl.sign.signatureLength) {
      return {
        verified: false,
        error: `Invalid signature length: expected ${nacl.sign.signatureLength}, got ${signature.length}`
      };
    }
    
    const verified = nacl.sign.detached.verify(message, signature, publicKey);
    
    return { verified };
  } catch (error) {
    logger.error('Signature verification error:', error);
    return {
      verified: false,
      error: error instanceof Error ? error.message : 'Unknown error'
    };
  }
}
