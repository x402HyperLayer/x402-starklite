import Database from 'better-sqlite3';
import { ProofRecord } from '../proof/types.js';
import { logger } from '../utils/logger.js';

export class ProofStore {
  private db: Database.Database;
  
  constructor(dbPath: string) {
    this.db = new Database(dbPath);
    this.initializeDatabase();
  }
  
  private initializeDatabase(): void {
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS proofs (
        id TEXT PRIMARY KEY,
        chain TEXT NOT NULL,
        timestamp TEXT NOT NULL,
        payload TEXT NOT NULL,
        signature TEXT NOT NULL,
        receivedAt TEXT NOT NULL,
        sizeRaw INTEGER NOT NULL,
        sizeGzip INTEGER NOT NULL,
        verifierStatus TEXT NOT NULL DEFAULT 'pending',
        verifierMessage TEXT,
        verifiedAt TEXT
      )
    `);
    
    this.db.exec(`
      CREATE INDEX IF NOT EXISTS idx_chain ON proofs(chain);
      CREATE INDEX IF NOT EXISTS idx_timestamp ON proofs(timestamp);
      CREATE INDEX IF NOT EXISTS idx_verifierStatus ON proofs(verifierStatus);
    `);
    
    logger.info('Database initialized successfully');
  }
  
  saveProof(proof: ProofRecord): void {
    const stmt = this.db.prepare(`
      INSERT INTO proofs (
        id, chain, timestamp, payload, signature,
        receivedAt, sizeRaw, sizeGzip, verifierStatus
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run(
      proof.id,
      proof.chain,
      proof.timestamp,
      JSON.stringify(proof.payload),
      proof.signature,
      proof.receivedAt,
      proof.sizeRaw,
      proof.sizeGzip,
      proof.verifierStatus
    );
    
    logger.info(`Proof saved: ${proof.id}`);
  }
  
  getProof(id: string): ProofRecord | null {
    const stmt = this.db.prepare('SELECT * FROM proofs WHERE id = ?');
    const row = stmt.get(id) as any;
    
    if (!row) {
      return null;
    }
    
    return {
      id: row.id,
      chain: row.chain,
      timestamp: row.timestamp,
      payload: JSON.parse(row.payload),
      signature: row.signature,
      receivedAt: row.receivedAt,
      sizeRaw: row.sizeRaw,
      sizeGzip: row.sizeGzip,
      verifierStatus: row.verifierStatus,
      verifierMessage: row.verifierMessage,
      verifiedAt: row.verifiedAt
    };
  }
  
  updateVerifierStatus(
    id: string,
    status: 'pending' | 'submitted' | 'verified' | 'failed',
    message?: string
  ): void {
    const stmt = this.db.prepare(`
      UPDATE proofs 
      SET verifierStatus = ?, 
          verifierMessage = ?,
          verifiedAt = ?
      WHERE id = ?
    `);
    
    const verifiedAt = status === 'verified' ? new Date().toISOString() : null;
    stmt.run(status, message || null, verifiedAt, id);
    
    logger.info(`Proof ${id} verifier status updated: ${status}`);
  }
  
  getMetrics(): {
    totalProofs: number;
    byStatus: Record<string, number>;
    byChain: Record<string, number>;
    totalSizeRaw: number;
    totalSizeGzip: number;
  } {
    const totalProofs = this.db.prepare('SELECT COUNT(*) as count FROM proofs').get() as { count: number };
    
    const byStatus = this.db.prepare(`
      SELECT verifierStatus, COUNT(*) as count 
      FROM proofs 
      GROUP BY verifierStatus
    `).all() as { verifierStatus: string; count: number }[];
    
    const byChain = this.db.prepare(`
      SELECT chain, COUNT(*) as count 
      FROM proofs 
      GROUP BY chain
    `).all() as { chain: string; count: number }[];
    
    const sizes = this.db.prepare(`
      SELECT SUM(sizeRaw) as totalRaw, SUM(sizeGzip) as totalGzip 
      FROM proofs
    `).get() as { totalRaw: number; totalGzip: number };
    
    return {
      totalProofs: totalProofs.count,
      byStatus: Object.fromEntries(byStatus.map(s => [s.verifierStatus, s.count])),
      byChain: Object.fromEntries(byChain.map(c => [c.chain, c.count])),
      totalSizeRaw: sizes.totalRaw || 0,
      totalSizeGzip: sizes.totalGzip || 0
    };
  }
  
  close(): void {
    this.db.close();
  }
}
