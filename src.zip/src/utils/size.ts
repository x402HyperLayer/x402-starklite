import pako from 'pako';

export interface SizeMetrics {
  rawBytes: number;
  gzipBytes: number;
  compressionRatio: number;
}

export function calculateSize(data: string | object): SizeMetrics {
  const jsonString = typeof data === 'string' ? data : JSON.stringify(data);
  const rawBytes = Buffer.byteLength(jsonString, 'utf8');
  
  const compressed = pako.gzip(jsonString);
  const gzipBytes = compressed.length;
  
  const compressionRatio = rawBytes > 0 ? gzipBytes / rawBytes : 0;
  
  return {
    rawBytes,
    gzipBytes,
    compressionRatio
  };
}

export function formatBytes(bytes: number): string {
  if (bytes === 0) return '0 Bytes';
  
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(2))} ${sizes[i]}`;
}
