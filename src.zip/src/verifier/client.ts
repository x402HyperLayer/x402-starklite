import axios, { AxiosError } from 'axios';
import { StarkProof } from '../proof/types.js';
import { logger } from '../utils/logger.js';
import { ProofStorage } from '../proof/storage.js';

export interface VerifierResponse {
  success: boolean;
  message: string;
  verificationId?: string;
}

export class VerifierClient {
  private maxRetries = 3;
  private baseDelay = 1000;
  
  constructor(
    private apiUrl: string,
    private apiKey: string,
    private storage: ProofStorage
  ) {}
  
  async submitProof(proof: StarkProof): Promise<VerifierResponse> {
    logger.info(`Submitting proof ${proof.id} to verifier: ${this.apiUrl}`);
    
    await this.storage.updateVerifierStatus(proof.id, 'submitted');
    
    for (let attempt = 0; attempt < this.maxRetries; attempt++) {
      try {
        const response = await axios.post<VerifierResponse>(
          this.apiUrl,
          {
            proof,
            timestamp: new Date().toISOString()
          },
          {
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${this.apiKey}`,
              'X-Proof-Id': proof.id
            },
            timeout: 30000
          }
        );
        
        if (response.data.success) {
          await this.storage.updateVerifierStatus(
            proof.id,
            'verified',
            response.data.message
          );
          logger.info(`Proof ${proof.id} verified successfully`);
        } else {
          await this.storage.updateVerifierStatus(
            proof.id,
            'failed',
            response.data.message
          );
          logger.warn(`Proof ${proof.id} verification failed: ${response.data.message}`);
        }
        
        return response.data;
      } catch (error) {
        const isLastAttempt = attempt === this.maxRetries - 1;
        
        if (axios.isAxiosError(error)) {
          const axiosError = error as AxiosError;
          logger.error(
            `Verifier request failed (attempt ${attempt + 1}/${this.maxRetries}):`,
            axiosError.message
          );
          
          if (isLastAttempt) {
            await this.storage.updateVerifierStatus(
              proof.id,
              'failed',
              `Verification failed after ${this.maxRetries} attempts: ${axiosError.message}`
            );
            
            return {
              success: false,
              message: `Failed after ${this.maxRetries} attempts: ${axiosError.message}`
            };
          }
        } else {
          logger.error(`Unexpected error:`, error);
          
          if (isLastAttempt) {
            await this.storage.updateVerifierStatus(
              proof.id,
              'failed',
              'Unexpected error during verification'
            );
            
            return {
              success: false,
              message: 'Unexpected error during verification'
            };
          }
        }
        
        const delay = this.baseDelay * Math.pow(2, attempt);
        logger.info(`Retrying in ${delay}ms...`);
        await this.sleep(delay);
      }
    }
    
    return {
      success: false,
      message: 'Verification failed after all retries'
    };
  }
  
  private sleep(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}
