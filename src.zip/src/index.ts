import express from 'express';
import compression from 'compression';
import { config } from './config.js';
import { ProofStore } from './db/store.js';
import { ProofStorage } from './proof/storage.js';
import { VerifierClient } from './verifier/client.js';
import { createRouter } from './api/routes.js';
import { logger } from './utils/logger.js';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();

app.use(compression());
app.use(express.json());

app.use((req, res, next) => {
  res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
  res.setHeader('Pragma', 'no-cache');
  res.setHeader('Expires', '0');
  next();
});

const store = new ProofStore(config.dbPath);
const storage = new ProofStorage(store);
const verifierClient = new VerifierClient(
  config.verifierApiUrl,
  config.verifierApiKey,
  storage
);

const apiRouter = createRouter(store, storage, verifierClient);
app.use('/api/v1', apiRouter);

const docsPath = path.join(__dirname, '..', 'docs');
app.use('/docs', express.static(docsPath));

app.get('/', (req, res) => {
  res.redirect('/docs');
});

app.get('/health', (req, res) => {
  res.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    version: '1.0.0'
  });
});

const server = app.listen(config.port, '0.0.0.0', () => {
  logger.info(`x402-stark-lite server running on http://0.0.0.0:${config.port}`);
  logger.info(`API: http://0.0.0.0:${config.port}/api/v1`);
  logger.info(`Dashboard: http://0.0.0.0:${config.port}/docs`);
  logger.info(`Database: ${config.dbPath}`);
  logger.info(`Verifier: ${config.verifierApiUrl}`);
});

process.on('SIGTERM', () => {
  logger.info('SIGTERM received, shutting down gracefully');
  server.close(() => {
    store.close();
    logger.info('Server closed');
    process.exit(0);
  });
});

process.on('SIGINT', () => {
  logger.info('SIGINT received, shutting down gracefully');
  server.close(() => {
    store.close();
    logger.info('Server closed');
    process.exit(0);
  });
});
