import dotenv from 'dotenv';
import { logger } from './utils/logger.js';

dotenv.config();

export interface Config {
  port: number;
  dbPath: string;
  verifierApiUrl: string;
  verifierApiKey: string;
  signerPublicKey: string;
  sigAlgo: string;
}

function getEnvOrThrow(key: string): string {
  const value = process.env[key];
  if (!value) {
    logger.error(`Missing required environment variable: ${key}`);
    throw new Error(`Missing required environment variable: ${key}`);
  }
  return value;
}

function getEnvOrDefault(key: string, defaultValue: string): string {
  return process.env[key] || defaultValue;
}

export function loadConfig(): Config {
  return {
    port: parseInt(getEnvOrDefault('PORT', '8080'), 10),
    dbPath: getEnvOrDefault('DB_PATH', './x402.db'),
    verifierApiUrl: getEnvOrDefault('VERIFIER_API_URL', 'https://verifier.example.com/verify'),
    verifierApiKey: getEnvOrDefault('VERIFIER_API_KEY', ''),
    signerPublicKey: getEnvOrDefault('SIGNER_PUBLIC_KEY', ''),
    sigAlgo: getEnvOrDefault('SIG_ALGO', 'ed25519')
  };
}

export const config = loadConfig();
