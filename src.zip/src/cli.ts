#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { ProofStore } from './db/store.js';
import { ProofStorage } from './proof/storage.js';
import { VerifierClient } from './verifier/client.js';
import { validateStarkProof } from './proof/validator.js';
import { verifySignature } from './proof/signer.js';
import { config } from './config.js';
import { logger } from './utils/logger.js';
import { StarkProof } from './proof/types.js';

const command = process.argv[2];
const arg = process.argv[3];

async function ingestProof(filePath: string): Promise<void> {
  try {
    logger.info(`Reading proof from ${filePath}`);
    const fileContent = readFileSync(filePath, 'utf-8');
    const proofData = JSON.parse(fileContent);
    
    const validationResult = validateStarkProof(proofData);
    if (!validationResult.valid) {
      logger.error('Validation failed:', validationResult.errors);
      process.exit(1);
    }
    
    const proof = proofData as StarkProof;
    
    const canonicalJson = JSON.stringify({
      id: proof.id,
      chain: proof.chain,
      timestamp: proof.timestamp,
      payload: proof.payload
    });
    
    const sigVerification = verifySignature(
      canonicalJson,
      proof.signature,
      config.signerPublicKey
    );
    
    logger.info(`Signature verification: ${sigVerification.verified ? 'PASSED' : 'FAILED'}`);
    if (!sigVerification.verified) {
      logger.warn(`Signature error: ${sigVerification.error}`);
    }
    
    const store = new ProofStore(config.dbPath);
    const storage = new ProofStorage(store);
    const verifierClient = new VerifierClient(
      config.verifierApiUrl,
      config.verifierApiKey,
      storage
    );
    
    const record = await storage.saveProof(proof);
    logger.info(`Proof ingested: ${proof.id}`);
    logger.info(`Raw size: ${record.sizeRaw} bytes, Gzip: ${record.sizeGzip} bytes`);
    
    logger.info('Submitting to verifier...');
    const verifierResponse = await verifierClient.submitProof(proof);
    
    if (verifierResponse.success) {
      logger.info('Verifier accepted proof');
    } else {
      logger.warn(`Verifier response: ${verifierResponse.message}`);
    }
    
    store.close();
  } catch (error) {
    logger.error('Ingest failed:', error);
    process.exit(1);
  }
}

async function exportProof(proofId: string): Promise<void> {
  try {
    const store = new ProofStore(config.dbPath);
    const proof = store.getProof(proofId);
    
    if (!proof) {
      logger.error(`Proof not found: ${proofId}`);
      store.close();
      process.exit(1);
    }
    
    const outputFile = `proof-${proofId}.json`;
    writeFileSync(outputFile, JSON.stringify(proof, null, 2));
    
    logger.info(`Proof exported to ${outputFile}`);
    logger.info(`Status: ${proof.verifierStatus}`);
    if (proof.verifierMessage) {
      logger.info(`Verifier message: ${proof.verifierMessage}`);
    }
    
    store.close();
  } catch (error) {
    logger.error('Export failed:', error);
    process.exit(1);
  }
}

function showUsage(): void {
  console.log(`
x402-stark-lite CLI

Usage:
  npm run cli ingest <file>    Ingest a proof from JSON file
  npm run cli export <id>      Export a proof by ID

Examples:
  npm run cli ingest ./proof.json
  npm run cli export abc123
  `);
}

if (!command) {
  showUsage();
  process.exit(0);
}

switch (command) {
  case 'ingest':
    if (!arg) {
      logger.error('Missing file path argument');
      showUsage();
      process.exit(1);
    }
    ingestProof(arg);
    break;
    
  case 'export':
    if (!arg) {
      logger.error('Missing proof ID argument');
      showUsage();
      process.exit(1);
    }
    exportProof(arg);
    break;
    
  default:
    logger.error(`Unknown command: ${command}`);
    showUsage();
    process.exit(1);
}
