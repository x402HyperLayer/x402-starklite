import express, { Request, Response } from 'express';
import multer from 'multer';
import { ProofStore } from '../db/store.js';
import { ProofStorage } from '../proof/storage.js';
import { VerifierClient } from '../verifier/client.js';
import { validateStarkProof } from '../proof/validator.js';
import { verifySignature } from '../proof/signer.js';
import { StarkProof } from '../proof/types.js';
import { logger } from '../utils/logger.js';
import { config } from '../config.js';

const upload = multer({ storage: multer.memoryStorage() });

export function createRouter(
  store: ProofStore,
  storage: ProofStorage,
  verifierClient: VerifierClient
): express.Router {
  const router = express.Router();
  
  router.post('/proofs', express.json({ limit: '10mb' }), async (req: Request, res: Response) => {
    try {
      const validationResult = validateStarkProof(req.body);
      
      if (!validationResult.valid) {
        return res.status(400).json({
          error: 'Validation failed',
          details: validationResult.errors
        });
      }
      
      const proof = req.body as StarkProof;
      
      const canonicalJson = JSON.stringify({
        id: proof.id,
        chain: proof.chain,
        timestamp: proof.timestamp,
        payload: proof.payload
      });
      
      const sigVerification = verifySignature(
        canonicalJson,
        proof.signature,
        config.signerPublicKey
      );
      
      if (!sigVerification.verified) {
        logger.warn(`Signature verification failed for proof ${proof.id}: ${sigVerification.error}`);
      }
      
      const record = await storage.saveProof(proof);
      
      verifierClient.submitProof(proof).catch(err => {
        logger.error(`Background verifier submission failed for ${proof.id}:`, err);
      });
      
      return res.status(201).json({
        success: true,
        proofId: proof.id,
        validation: {
          schema: true,
          signature: sigVerification.verified,
          signatureError: sigVerification.error
        },
        metrics: {
          rawBytes: record.sizeRaw,
          gzipBytes: record.sizeGzip,
          compressionRatio: record.sizeGzip / record.sizeRaw
        },
        receivedAt: record.receivedAt
      });
    } catch (error) {
      logger.error('Error processing proof:', error);
      return res.status(500).json({
        error: 'Internal server error',
        message: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });
  
  router.get('/proofs/:id', (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const proof = store.getProof(id);
      
      if (!proof) {
        return res.status(404).json({
          error: 'Proof not found',
          proofId: id
        });
      }
      
      return res.json({
        proof,
        metrics: {
          rawBytes: proof.sizeRaw,
          gzipBytes: proof.sizeGzip,
          compressionRatio: proof.sizeGzip / proof.sizeRaw
        }
      });
    } catch (error) {
      logger.error('Error retrieving proof:', error);
      return res.status(500).json({
        error: 'Internal server error',
        message: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });
  
  router.get('/metrics', (req: Request, res: Response) => {
    try {
      const metrics = store.getMetrics();
      return res.json(metrics);
    } catch (error) {
      logger.error('Error retrieving metrics:', error);
      return res.status(500).json({
        error: 'Internal server error',
        message: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });
  
  return router;
}
